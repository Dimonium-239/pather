class AppUser {
  const AppUser({required this.uid});

  final String uid;
}