import 'package:pather/src/features/sign_in/domain/app_user.dart';

abstract class AuthRepository {
  Stream<AppUser?> authStateChanges();
  Future<AppUser> singInAnonymously();
  Future<void> singOut();
}